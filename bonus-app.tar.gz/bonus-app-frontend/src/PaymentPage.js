import React from 'react';

const PaymentPage = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h2>Оплата</h2>
      <p>Здесь можно выбрать пакет услуг и оплатить его.</p>
      <button>Оплатить пакет</button>
    </div>
  );
};

export default PaymentPage;